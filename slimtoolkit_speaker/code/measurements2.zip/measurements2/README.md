Change the font sizes inside final.py file. All the fonts are written on the top. Adjust accordingly.
Run the following command to generate the graphs:
python3 measurement2.py
This command will also generate some xlsx files. Ignore them :-)
